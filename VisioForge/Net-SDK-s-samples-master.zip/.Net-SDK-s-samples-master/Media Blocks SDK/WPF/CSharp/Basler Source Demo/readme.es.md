# Media Blocks SDK .Net - Basler Source Demo (WPF)

Basler Source Demo es una aplicación que utiliza Media Blocks SDK .Net para previsualizar o capturar vídeo de las cámaras Basler GigE/USB3/GenICam.

## Características

- Reproducir vídeo desde la fuente de la cámara Basler


## Versiones de .Net compatibles

- .Net 4.7.2
- .Net Core 3.1
- .Net 5
- .Net 6
- .Net 7
- .Net 8

---

[Media Blocks SDK .Net product page](https://www.visioforge.com/media-blocks-sdk)
