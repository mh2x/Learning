﻿# VisioForge Media Blocks SDK .Net

## Audio Capture Demo (C#/WPF, cross-platform)

La muestra, desarrollada por VisioForge Media Blocks SDK .Net, muestra un ejemplo completo de implementación de la funcionalidad de grabación de audio dentro de una aplicación WPF.

## Versiones de .Net compatibles

* .Net 4.7.2
* .Net Core 3.1
* .Net 5
* .Net 6
* .Net 7
* .Net 8

---

[Visit the product page.](https://www.visioforge.com/media-blocks-sdk-net)
