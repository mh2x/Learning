# Media Blocks SDK .Net - Allied Vision Source Demo (WPF)

Allied Vision Source Demo es una aplicación que utiliza Media Blocks SDK .Net para previsualizar o capturar vídeo de las cámaras Allied Vision GigE/USB3/GenICam.

## Características

- Reproducir vídeo desde la fuente de la cámara Allied Vision


## Versiones de .Net compatibles

- .Net 4.7.2
- .Net Core 3.1
- .Net 5
- .Net 6
- .Net 7
- .Net 8

---

[Media Blocks SDK .Net product page](https://www.visioforge.com/media-blocks-sdk)
