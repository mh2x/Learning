﻿# Media Blocks SDK .Net - Allied Vision Source Demo (WPF)

Allied Vision Source Demo is an application that uses the Media Blocks SDK .Net to preview or capture video from Allied Vision GigE/USB3/GenICam cameras.

## Features

- Play video from Allied Vision camera source

## Supported frameworks

- .Net 4.7.2
- .Net Core 3.1
- .Net 5
- .Net 6
- .Net 7
- .Net 8

---

[Media Blocks SDK .Net product page](https://www.visioforge.com/media-blocks-sdk)
