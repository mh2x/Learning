using ScreenCaptureMB;

// This is the main entry point of the application.
NSApplication.Init();
NSApplication.Main(args);